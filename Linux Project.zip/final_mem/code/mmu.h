#ifndef MMU_H
#define MMU_H

#include "headers.h"

/* Memory Management Functions */
void init_mmu(void);
void cleanup_mmu(void);
int handle_page_fault(pcb *process, int virtual_addr, int current_time, char rw);
void allocate_process_memory(pcb *process, int current_time);
void free_process_memory(pcb *process);
int check_disk_completion(int current_time);
int simulate_memory_access(pcb *process, int current_time);

#endif /* MMU_H */