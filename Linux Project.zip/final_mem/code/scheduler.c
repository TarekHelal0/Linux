#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#include "headers.h"
#include "pri_queue.h"
#include "process_table.h"
#include "mmu.h"

#ifndef MSG_PROC_ARRIVAL
#define MSG_PROC_ARRIVAL 1
#endif

#ifndef MSG_PROC_FINISH
#define MSG_PROC_FINISH  2
#endif

#ifndef PID_TABLE_SIZE
#define PID_TABLE_SIZE 50000
#endif

int queueID;
int totalProcesses = 0;
int completed = 0;

int totalWait = 0, totalTurnaround = 0, totalBurst = 0;
float totalWTA = 0.0, totalWTASquared = 0.0;

pcb **processById;
pcb **processByPid;

void enqueueProcess(PriQueue **ready, pcb *process, int mode)
{
    int key;
    if (mode == HPF) key = (10-process->priority);
    else if (mode == SRTN) key = process->remainingTime;
    else key = 0;

    PriQueueInsertion(ready, key, process);
}

void logProcess(pcb *p, int time)
{
    static int lastTime = -1, lastId = -1, lastState = -1;
    if (lastTime == time && lastId == p->id && lastState == p->state) return;

    FILE *f = fopen(schedulerLogFile, "a");
    if (!f) return;

    const char *st[] = {"STARTED", "RESUMED", "STOPPED", "FINISHED", "RUNNING"};

    fprintf(f, "At time %d process %d %s arr %d total %d remain %d wait %d ",
            time, p->id, st[p->state], p->arrivalTime, p->burstTime, p->remainingTime, p->waitTime);

    if (p->state == FINISHED)
        fprintf(f, "TA %d WTA %.2f\n", p->turnaroundTime, p->weightedTurnaroundTime);
    else
        fprintf(f, "\n");

    fclose(f);

    lastTime = time;
    lastId = p->id;
    lastState = p->state;
}

int receiveTermination(void)
{
    ProcessTerminationMsg msg;
    if (msgrcv(queueID, &msg, sizeof(ProcessTerminationMsg) - sizeof(long),
               MSG_PROC_FINISH, IPC_NOWAIT) == -1)
        return -1;
    return msg.pid;
}

pcb* receiveProcess(void)
{
    ProcessInputMsg msg;
    if (msgrcv(queueID, &msg, sizeof(ProcessInputMsg) - sizeof(long),
               MSG_PROC_ARRIVAL, IPC_NOWAIT) == -1)
        return NULL;

    pcb *p = (pcb*)malloc(sizeof(pcb));
    if (!p) return NULL;

    p->id = msg.data.ID;
    p->arrivalTime = msg.data.Time_of_Arrival;
    p->burstTime = msg.data.Time_of_Running;
    p->remainingTime = p->burstTime;
    p->priority = msg.data.Priority;
    p->dependencyId = msg.data.dependencyId;
    
    p->base_disk = msg.data.base_disk;
    p->limit_pages = msg.data.limit_pages;
    p->memory_allocated = 0;
    p->blocked_state = NOT_BLOCKED;
    p->disk_completion_time = -1;
    p->next_access_index = 0;
    snprintf(p->access_filename, sizeof(p->access_filename), "process_%d.access", p->id);

    p->pid = -1;
    p->state = STARTED;
    p->waitTime = 0;

    p->startTime = -1;
    p->resumedTime = -1;
    p->stoppedTime = -1;
    p->finishTime = -1;

    p->remainingTimeAfterStop = p->remainingTime;
    p->turnaroundTime = -1;
    p->weightedTurnaroundTime = -1;

    return p;
}

void updateWait(pcb *p, int now)
{
    if (!p) return;
    int executed = p->burstTime - p->remainingTime;
    int w = now - p->arrivalTime - executed;
    p->waitTime = (w < 0) ? 0 : w;
}

void updateRemain(pcb *p, int now)
{
    if (!p || p->resumedTime == -1) return;
    int d = now - p->resumedTime;
    p->remainingTime = p->remainingTimeAfterStop - d;
    if (p->remainingTime < 0) p->remainingTime = 0;
}

void releaseDependents(PriQueue **depWait, PriQueue **ready, int mode, int finishedId)
{
    if (!depWait || !ready) return;

    PriQueue *temp = PriQueueCreation();

    while (!PriQueue_IsEmpty(depWait))
    {
        pcb *p = PriQueue_Dequeue(depWait);
        if (p->dependencyId == finishedId || p->dependencyId == -1)
            enqueueProcess(ready, p, mode);
        else
            enqueueProcess(&temp, p, mode);
    }

    while (!PriQueue_IsEmpty(&temp))
    {
        pcb *p = PriQueue_Dequeue(&temp);
        enqueueProcess(depWait, p, mode);
    }

    PriQueue_Elimination(&temp);
}

void registerPid(pcb *p, pid_t pid)
{
    p->pid = pid;
    if (pid > 0 && pid < PID_TABLE_SIZE)
        processByPid[pid] = p;
}

pcb* pcbFromPid(int pid)
{
    if (pid > 0 && pid < PID_TABLE_SIZE)
        return processByPid[pid];
    return NULL;
}

void unregisterPid(int pid)
{
    if (pid > 0 && pid < PID_TABLE_SIZE)
        processByPid[pid] = NULL;
}

void finalizeProcess(pcb **current, ProcessTable **ptable, PriQueue **depWait, 
                     PriQueue **ready, int *finished, int strategy,
                     int now, pcb *done)
{
    if (!done) return;

    done->state = FINISHED;
    done->finishTime = now;
    done->remainingTime = 0;
    done->remainingTimeAfterStop = 0;
    done->turnaroundTime = done->finishTime - done->arrivalTime;
    done->weightedTurnaroundTime = (float)done->turnaroundTime / done->burstTime;

    logProcess(done, now);

    finished[done->id] = 1;
    completed++;

    totalWait += done->waitTime;
    totalTurnaround += done->turnaroundTime;
    totalWTA += done->weightedTurnaroundTime;
    totalWTASquared += done->weightedTurnaroundTime * done->weightedTurnaroundTime;

    if (strategy == RR) {
        free_process_memory(done);
    }

    releaseDependents(depWait, ready, strategy, done->id);

    unregisterPid(done->pid);
    processById[done->id] = NULL;

    PCB_Remove(ptable, done->id);

    if (*current == done)
        *current = NULL;
}

int main(int argc, char **argv)
{
    if (argc < 3) exit(1);

    totalProcesses = atoi(argv[1]);
    int strategy = atoi(argv[2]);

    int quantum = 1;
    if (strategy == RR && argc > 3)
        quantum = atoi(argv[3]);

    key_t key = ftok(MSGQUEUENAME, MSGQUEUEKEY);
    queueID = msgget(key, 0666);
    if (queueID == -1) exit(1);

    initClk();
    
    if (strategy == RR) {
        init_mmu();
    }

    ProcessTable *ptable = ProcessTable_Creation();
    PriQueue *ready = PriQueueCreation();
    PriQueue *depWait = PriQueueCreation();

    int *finished = calloc(totalProcesses + 1, sizeof(int));
    processById = calloc(totalProcesses + 1, sizeof(pcb*));
    processByPid = calloc(PID_TABLE_SIZE, sizeof(pcb*));

    FILE *f = fopen(schedulerLogFile, "w");
    fprintf(f, "#At time x process y state arr w total z remain y wait k\n");
    fclose(f);

    pcb *current = NULL;

    while (1)
    {
        int now = getClk();

        if (current && strategy == RR && current->blocked_state == BLOCKED_DISK_ACCESS) {
            if (now >= current->disk_completion_time) {
                current->blocked_state = NOT_BLOCKED;
                current->disk_completion_time = -1;
            } else {
                current->state = STOPPED;
                current->stoppedTime = now;
                current->remainingTimeAfterStop = current->remainingTime;
                
                enqueueProcess(&ready, current, strategy);
                current = NULL;
            }
        }

        if (current && (strategy != RR || current->blocked_state == NOT_BLOCKED)) {
            updateRemain(current, now);
        }

        int termPid;
        while ((termPid = receiveTermination()) != -1)
        {
            pcb *done = pcbFromPid(termPid);
            finalizeProcess(&current, &ptable, &depWait, &ready, finished, strategy, now, done);
        }

        if (current && (current->state == STARTED || current->state == RESUMED) 
            && (strategy != RR || current->blocked_state == NOT_BLOCKED))
            current->state = RUNNING;

        pcb *in;
        while ((in = receiveProcess()))
        {
            totalBurst += in->burstTime;

            if (in->id >= 1 && in->id <= totalProcesses)
                processById[in->id] = in;

            if (strategy == RR) {
                allocate_process_memory(in, now);
            }

            if (in->dependencyId == -1 ||
                (in->dependencyId >= 1 && in->dependencyId <= totalProcesses && finished[in->dependencyId]))
            {
                enqueueProcess(&ready, in, strategy);
            }
            else
            {
                enqueueProcess(&depWait, in, strategy);

                if (strategy == HPF && in->dependencyId >= 1 && in->dependencyId <= totalProcesses)
                {
                    pcb *dep = processById[in->dependencyId];
                    if (dep && dep->priority < in->priority)
                        dep->priority = in->priority;
                }
            }

            PCB_Addition(&ptable, in);
        }

        if (strategy == RR) {
            for (int i = 1; i <= totalProcesses; i++) {
                pcb *proc = processById[i];
                if (proc && proc->blocked_state == BLOCKED_DISK_ACCESS && 
                    now >= proc->disk_completion_time) {
                    proc->blocked_state = NOT_BLOCKED;
                    proc->disk_completion_time = -1;
                    
                    if (proc->pid > 0) {
                        kill(proc->pid, SIGCONT);
                    }
                    
                    int found = 0;
                    PriQueue *temp = PriQueueCreation();
                    while (!PriQueue_IsEmpty(&ready)) {
                        pcb *p = PriQueue_Dequeue(&ready);
                        if (p->id == proc->id) {
                            found = 1;
                        }
                        enqueueProcess(&temp, p, strategy);
                    }
                    while (!PriQueue_IsEmpty(&temp)) {
                        pcb *p = PriQueue_Dequeue(&temp);
                        enqueueProcess(&ready, p, strategy);
                    }
                    PriQueue_Elimination(&temp);
                    
                    if (!found) {
                        enqueueProcess(&ready, proc, strategy);
                    }
                }
            }
        }

        if (current && strategy == RR &&
            (now - current->resumedTime) >= quantum &&
            current->remainingTime > 0 &&
            current->blocked_state == NOT_BLOCKED &&
            !PriQueue_IsEmpty(&ready))
        {
            current->state = STOPPED;
            current->stoppedTime = now;
            current->remainingTimeAfterStop = current->remainingTime;
            kill(current->pid, SIGSTOP);
            logProcess(current, now);

            enqueueProcess(&ready, current, strategy);
            current = NULL;
        }

        if (strategy == SRTN && current && !PriQueue_IsEmpty(&ready))
        {
            pcb *candidate = PriQueue_Dequeue(&ready);
            if (candidate->remainingTime < current->remainingTime)
            {
                current->state = STOPPED;
                current->stoppedTime = now;
                current->remainingTimeAfterStop = current->remainingTime;
                kill(current->pid, SIGSTOP);
                logProcess(current, now);

                enqueueProcess(&ready, current, strategy);
                current = candidate;

                if (current->pid == -1)
                {
                    pid_t pid = fork();
                    if (pid == 0)
                    {
                        char rt[10];
                        sprintf(rt, "%d", current->remainingTime);
                        execl("./process.out", "./process.out", rt, NULL);
                        exit(0);
                    }
                    registerPid(current, pid);
                    current->startTime = now;
                }

                current->resumedTime = now;
                current->remainingTimeAfterStop = current->remainingTime;
                current->state = RESUMED;
                kill(current->pid, SIGCONT);
                logProcess(current, now);
                continue;
            }
            else
            {
                enqueueProcess(&ready, candidate, strategy);
            }
        }

        if (strategy == HPF && current && !PriQueue_IsEmpty(&ready))
        {
            pcb *candidate = PriQueue_Dequeue(&ready);
            if (candidate->priority > current->priority)
            {
                current->state = STOPPED;
                current->stoppedTime = now;
                current->remainingTimeAfterStop = current->remainingTime;
                kill(current->pid, SIGSTOP);
                logProcess(current, now);

                enqueueProcess(&ready, current, strategy);
                current = candidate;

                if (current->pid == -1)
                {
                    pid_t pid = fork();
                    if (pid == 0)
                    {
                        char rt[10];
                        sprintf(rt, "%d", current->remainingTime);
                        execl("./process.out", "./process.out", rt, NULL);
                        exit(0);
                    }
                    registerPid(current, pid);
                    current->startTime = now;
                }

                current->resumedTime = now;
                current->remainingTimeAfterStop = current->remainingTime;
                current->state = RESUMED;
                kill(current->pid, SIGCONT);
                logProcess(current, now);
                continue;
            }
            else
            {
                enqueueProcess(&ready, candidate, strategy);
            }
        }

        if (!current)
        {
            pcb *next = PriQueue_Dequeue(&ready);
            if (next)
            {
                if (strategy == RR) {
                    int attempts = 0;
                    while (next && next->blocked_state != NOT_BLOCKED && attempts < totalProcesses) {
                        enqueueProcess(&ready, next, strategy);
                        next = PriQueue_Dequeue(&ready);
                        attempts++;
                    }
                    
                    if (!next || next->blocked_state != NOT_BLOCKED) {
                        if (next) enqueueProcess(&ready, next, strategy);
                        continue;
                    }
                }
                
                updateWait(next, now);

                if (next->pid == -1)
                {
                    pid_t pid = fork();
                    if (pid == 0)
                    {
                        char rt[10];
                        sprintf(rt, "%d", next->remainingTime);
                        execl("./process.out", "./process.out", rt, NULL);
                        exit(0);
                    }
                    registerPid(next, pid);
                    next->startTime = now;
                }
                else
                {
                    kill(next->pid, SIGCONT);
                }

                next->resumedTime = now;
                next->remainingTimeAfterStop = next->remainingTime;
                next->state = (next->startTime == now) ? STARTED : RESUMED;

                logProcess(next, now);
                current = next;
                
                if (strategy == RR && current->blocked_state == NOT_BLOCKED) {
                    simulate_memory_access(current, now);
                }
            }
        }

        if (current && current->state == RUNNING)
            logProcess(current, now);

        int all_finished = 1;
        for (int i = 1; i <= totalProcesses; i++) {
            if (!finished[i]) {
                all_finished = 0;
                break;
            }
        }

        if (all_finished && current == NULL && PriQueue_IsEmpty(&ready))
            break;
    }

    int totalTime = getClk();
    FILE *perf = fopen(schedulerPerfFile, "w");

    float avgWTA = totalWTA / totalProcesses;
    float stdWTA = sqrt((totalWTASquared / totalProcesses) - (avgWTA * avgWTA));

    fprintf(perf, "CPU utilization = %.2f\n", ((float)totalBurst / totalTime) * 100);
    fprintf(perf, "Avg WTA = %.2f\nAvg Waiting = %.2f\nStd WTA = %.2f\n",
            avgWTA, (float)totalWait / totalProcesses, stdWTA);
    fclose(perf);

    Process_table_Elimination(ptable);
    PriQueue_Elimination(&ready);
    PriQueue_Elimination(&depWait);
    
    if (strategy == RR) {
        cleanup_mmu();
    }

    free(finished);
    free(processById);
    free(processByPid);

    destroyClk(false);
    return 0;
}