#include "process_table.h"
#include <stdio.h>
#include <stdlib.h>

static PTEntry *makeEntry(pcb *p)
{
    PTEntry *e = (PTEntry *)malloc(sizeof(PTEntry));
    if (!e) return NULL;
    e->proc = p;
    e->next = NULL;
    return e;
}


ProcessTable *ProcessTable_Creation(void)
{
    ProcessTable *tbl = (ProcessTable *)malloc(sizeof(ProcessTable));
    if (!tbl) return NULL;

    tbl->head = makeEntry(NULL);
    if (!tbl->head) { free(tbl); return NULL; }

    return tbl;
}


void PCB_Addition(ProcessTable **tbl, pcb *proc)
{
    PTEntry *node = makeEntry(proc);
    if (!node) return;                       

    node->next          = (*tbl)->head->next;
    (*tbl)->head->next  = node;
}


void PCB_Remove(ProcessTable **tbl, int procID)
{
    PTEntry *prev = (*tbl)->head;
    PTEntry *cur  = prev->next;

    while (cur) {
        if (cur->proc && cur->proc->id == procID) {
            prev->next = cur->next;
            free(cur->proc);       
            free(cur);
            return;
        }
        prev = cur;
        cur  = cur->next;
    }
}


void ProcessTable_Display(ProcessTable *tbl)
{
    for (PTEntry *n = tbl->head->next; n; n = n->next)
        printf("%d ", n->proc->id);
    puts("");
}


void Process_table_Elimination(ProcessTable *tbl)
{
    if (!tbl) return;

    PTEntry *cur = tbl->head;
    while (cur) {
        PTEntry *nxt = cur->next;
        if (cur->proc) free(cur->proc);
        free(cur);
        cur = nxt;
    }
}


