#include <stdio.h>
#include <stdlib.h>
#include "pri_queue.h"


typedef struct PQNode {
    int      key;   
    pcb     *item; 
    struct PQNode *next;
} PQNode;


struct PriQueue {
    PQNode  *head;
    unsigned count;
};


static PQNode *node_new(int key, pcb *item)
{
    PQNode *n = (PQNode *)malloc(sizeof(PQNode));
    if (!n) {
        perror("create node – out of memory");
        exit(EXIT_FAILURE);
    }
    n->key  = key;
    n->item = item;
    n->next = NULL;
    return n;
}


PriQueue *PriQueueCreation(void)
{
    PriQueue *q = (PriQueue *)malloc(sizeof(PriQueue));
    if (!q) {
        perror("create queue – out of memory");
        exit(EXIT_FAILURE);
    }
    q->head  = NULL;
    q->count = 0;
    return q;
}

void PriQueue_Elimination(PriQueue **queue)
{
    if (!queue || !*queue) return;
    PQNode *cur = (*queue)->head;
    while (cur) {
        PQNode *next = cur->next;
        free(cur);
        cur = next;
    }
    free(*queue);
    *queue = NULL;
}

int PriQueue_IsEmpty(PriQueue **queue)
{
    return (!queue || !*queue || (*queue)->count == 0);
}

void PriQueueInsertion(PriQueue **queue, int key, pcb *process)
{
    if (!queue) return;                 
    if (!*queue) *queue = PriQueueCreation();

    PQNode *newNode = node_new(key, process);
    (*queue)->count++;

   
    if (!(*queue)->head) {
        (*queue)->head = newNode;
        return;
    }

   
    if (key < (*queue)->head->key) {
        newNode->next  = (*queue)->head;
        (*queue)->head = newNode;
        return;
    }

    
    PQNode *prev = (*queue)->head;
    PQNode *curr = prev->next;
    while (curr && curr->key <= key) {
        prev = curr;
        curr = curr->next;
    }

   
    prev->next  = newNode;
    newNode->next = curr;
}

pcb *PriQueue_Dequeue(PriQueue **queue)
{
    if (PriQueue_IsEmpty(queue)) return NULL;

    PQNode *front = (*queue)->head;
    pcb    *proc  = front->item;
    (*queue)->head = front->next;
    free(front);
    (*queue)->count--;
    return proc;
}

void PriQueue_Display(PriQueue **queue)
{
    if (PriQueue_IsEmpty(queue)) {
        printf("[Priority Queue] <empty>\n");
        return;
    }

    printf("[Priority Queue] size = %u\n", (*queue)->count);
    for (PQNode *n = (*queue)->head; n; n = n->next) {
        printf("  • PCB %d  (key = %d)\n", n->item->id, n->key);
   }
}

