#include "mmu.h"
#include <string.h>
#include <signal.h>
#include <stdio.h>

#define TOTAL_PHYSICAL_PAGES 32

static int page_owners[TOTAL_PHYSICAL_PAGES];
static int page_virtual_numbers[TOTAL_PHYSICAL_PAGES];
static int reference_bits[TOTAL_PHYSICAL_PAGES];
static int dirty_bits[TOTAL_PHYSICAL_PAGES];
static int clock_hand = 0;
static FILE *mem_log = NULL;

void init_mmu(void) {
    for (int i = 0; i < TOTAL_PHYSICAL_PAGES; i++) {
        page_owners[i] = -1;
        page_virtual_numbers[i] = -1;
        reference_bits[i] = 0;
        dirty_bits[i] = 0;
    }
    
    mem_log = fopen("memory.log", "w");
    if (mem_log) {
        fprintf(mem_log, "# Memory Management Log\n\n");
    }
}

void cleanup_mmu(void) {
    if (mem_log) {
        fclose(mem_log);
        mem_log = NULL;
    }
}

static int find_free_page(void) {
    for (int i = 0; i < TOTAL_PHYSICAL_PAGES; i++) {
        if (page_owners[i] == -1) {
            return i;
        }
    }
    return -1;
}

static int second_chance_victim(void) {
    int start = clock_hand;
    
    while (1) {
        if (page_owners[clock_hand] == -1) {
            clock_hand = (clock_hand + 1) % TOTAL_PHYSICAL_PAGES;
            if (clock_hand == start) return -1;
            continue;
        }
        
        if (page_virtual_numbers[clock_hand] == -1) {
            clock_hand = (clock_hand + 1) % TOTAL_PHYSICAL_PAGES;
            if (clock_hand == start) {
                return -1;
            }
            continue;
        }
        
        if (reference_bits[clock_hand] == 0) {
            int victim = clock_hand;
            clock_hand = (clock_hand + 1) % TOTAL_PHYSICAL_PAGES;
            return victim;
        } else {
            reference_bits[clock_hand] = 0;
            clock_hand = (clock_hand + 1) % TOTAL_PHYSICAL_PAGES;
            
            if (clock_hand == start) {
                continue;
            }
        }
    }
    return -1; //just in case
}

void allocate_process_memory(pcb *process, int current_time) {
    if (!process || process->memory_allocated) return;
    
    int page_table_page = find_free_page();
    if (page_table_page == -1) {
        page_table_page = second_chance_victim();
        
        if (page_table_page == -1) {
            return;
        }
        
        if (dirty_bits[page_table_page]) {
            if (mem_log) {
                fprintf(mem_log, "Swapping out page %d to disk\n", page_table_page);
                fflush(mem_log);
            }
        }
        
        page_owners[page_table_page] = -1;
        page_virtual_numbers[page_table_page] = -1;
        reference_bits[page_table_page] = 0;
        dirty_bits[page_table_page] = 0;
    }
    
    
    process->page_table = malloc(sizeof(ProcessPageTable));
    if (process->page_table) {
        
        process->page_table->phys_page_table_page = page_table_page;
        
        
        process->page_table->size = 64;  
        process->page_table->base_disk = process->base_disk;
        process->page_table->limit_pages = process->limit_pages;
        
        
         process->page_table->entries = malloc(64 * sizeof(PageTableEntry));
        if (process->page_table->entries) {
             for (int i = 0; i < 64; i++) {
                process->page_table->entries[i].physical_page = -1;
                process->page_table->entries[i].flags = 0;
                 process->page_table->entries[i].disk_page = process->base_disk + i;
            }
         } else {
             process->page_table->entries = NULL;
         }
        
    }
    
    
    
    page_owners[page_table_page] = process->id;
    page_virtual_numbers[page_table_page] = -1;
    reference_bits[page_table_page] = 1;
    process->memory_allocated = 1;
    process->blocked_state = NOT_BLOCKED;
    
    if (mem_log) {
        fprintf(mem_log, "Allocated page %d for process %d page table\n", 
                page_table_page, process->id);
        fflush(mem_log);
    }
}

int handle_page_fault(pcb *process, int virtual_addr, int current_time, char rw) {
    if (!process) return -1;
    
    process->blocked_state = BLOCKED_DISK_ACCESS;
    
    
    if (process->pid > 0) {
        kill(process->pid, SIGSTOP);
    }
    
    if (mem_log) {
        fprintf(mem_log, "PageFault upon VA %d from process %d\n", 
                virtual_addr, process->id);
        fflush(mem_log);
    }
    
    int virtual_page = virtual_addr >> 4;
    
    int free_page = find_free_page();
    
    if (free_page != -1) {
        
        process->disk_completion_time = current_time + DISK_ACCESS_CYCLES;
        
        if (mem_log) {
            fprintf(mem_log, "Free Physical page %d allocated\n", free_page);
            fflush(mem_log);
        }
        
        page_owners[free_page] = process->id;
        page_virtual_numbers[free_page] = virtual_page;
        reference_bits[free_page] = 1;
        dirty_bits[free_page] = (rw == 'w') ? 1 : 0;
        
        int disk_page = process->base_disk + virtual_page;
        
        if (mem_log) {
            fprintf(mem_log, "At time %d disk address %d for process %d is loaded into memory page %d\n",
                    process->disk_completion_time, disk_page, process->id, free_page);
            fflush(mem_log);
        }
        
        return free_page;
    }
    
    
    int victim_page = second_chance_victim();
    if (victim_page == -1) {
        return -1;
    }
    
    
    int total_delay = DISK_ACCESS_CYCLES;  
    int is_dirty_eviction = 0;
    
    
    if (dirty_bits[victim_page]) {
        total_delay += DISK_ACCESS_CYCLES;  
        is_dirty_eviction = 1;
    }
    
    
    process->disk_completion_time = current_time + total_delay;
    
    
    
    if (is_dirty_eviction) {
        if (mem_log) {
            fprintf(mem_log, "Swapping out page %d to disk\n", victim_page);
            fflush(mem_log);
        }
    }
    
    // Free the victim page
    page_owners[victim_page] = -1;
    page_virtual_numbers[victim_page] = -1;
    reference_bits[victim_page] = 0;
    dirty_bits[victim_page] = 0;
    
    // Allocate page to new process
    page_owners[victim_page] = process->id;
    page_virtual_numbers[victim_page] = virtual_page;
    reference_bits[victim_page] = 1;
    dirty_bits[victim_page] = (rw == 'w') ? 1 : 0;
    
    int disk_page = process->base_disk + virtual_page;
    
    if (mem_log) {
        fprintf(mem_log, "At time %d disk address %d for process %d is loaded into memory page %d\n",
                process->disk_completion_time, disk_page, process->id, victim_page);
        fflush(mem_log);
    }
    
    return victim_page;
}

void free_process_memory(pcb *process) {
    if (!process) return;
    
    
    if (process->page_table) {
        
        if (process->page_table->entries) {
            free(process->page_table->entries);
        }
        
        free(process->page_table);
        process->page_table = NULL;
    }
    
    
    
    for (int i = 0; i < TOTAL_PHYSICAL_PAGES; i++) {
        if (page_owners[i] == process->id) {
            page_owners[i] = -1;
            page_virtual_numbers[i] = -1;
            reference_bits[i] = 0;
            dirty_bits[i] = 0;
        }
    }
    
    process->memory_allocated = 0;
    process->blocked_state = NOT_BLOCKED;
    process->disk_completion_time = -1;
}

int check_disk_completion(int current_time) {
    return 0;
}

static int is_page_in_memory(int pid, int virtual_page) {
    for (int i = 0; i < TOTAL_PHYSICAL_PAGES; i++) {
        if (page_owners[i] == pid && page_virtual_numbers[i] == virtual_page) {
            reference_bits[i] = 1;
            return 1;
        }
    }
    return 0;
}

int simulate_memory_access(pcb *process, int current_time) {
    if (!process || process->blocked_state != NOT_BLOCKED) {
        return 0;
    }
    
    FILE *access_file = fopen(process->access_filename, "r");
    if (!access_file) {
        return 0;
    }
    
    char line[256];
    int found_access = 0;
    int relative_time;
    char binary_str[20];
    char rw;
    
    while (fgets(line, sizeof(line), access_file)) {
        if (line[0] == '#' || line[0] == '\n') {
            continue;
        }
        
        if (sscanf(line, "%d %10s %c", &relative_time, binary_str, &rw) == 3) {
            if (relative_time == process->next_access_index) {
                found_access = 1;
                
                int virtual_addr = 0;
                for (int i = 0; i < 10 && binary_str[i] != '\0'; i++) {
                    virtual_addr = (virtual_addr << 1) | (binary_str[i] - '0');
                }
                
                int virtual_page = virtual_addr >> 4;
                
                if (is_page_in_memory(process->id, virtual_page)) {
                    if (rw == 'w') {
                        for (int i = 0; i < TOTAL_PHYSICAL_PAGES; i++) {
                            if (page_owners[i] == process->id && page_virtual_numbers[i] == virtual_page) {
                                dirty_bits[i] = 1;
                                break;
                            }
                        }
                    }
                    process->next_access_index++;
                } else {
                    int result = handle_page_fault(process, virtual_addr, current_time, rw);
                    if (result != -1) {
                        process->next_access_index++;
                    }
                }
                
                break;
            }
        }
    }
    
    fclose(access_file);
    return found_access ? 1 : 0;
}