#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <wait.h>

#include "headers.h"

/* ===============================
   Globals
   =============================== */
int SchedulerQueueID = -1;

/* ===============================
   Cleanup handler
   =============================== */
void clearResources(int signum)
{
    static int cleaned = 0;
    if (cleaned) return;
    cleaned = 1;

    if (SchedulerQueueID != -1)
    {
        msgctl(SchedulerQueueID, IPC_RMID, NULL);
    }

    destroyClk(false);
    killpg(getpgrp(), SIGINT);
    exit(0);
}

/* ===============================
   Main
   =============================== */
int main()
{
    signal(SIGINT, clearResources);

    /* ---------- Read process file ---------- */
    FILE *processFile = fopen("testcase1.txt", "r");
    if (!processFile) {
        perror("Unable to open testcase1.txt");
        exit(EXIT_FAILURE);
    }

    char buffer[256];
    int totalProcesses = 0;

    /* Count processes */
    while (fgets(buffer, sizeof(buffer), processFile)) {
        if (buffer[0] != '#' && buffer[0] != '\n')
            totalProcesses++;
    }
    rewind(processFile);

    struct DataForProcess *procList =
        malloc(sizeof(struct DataForProcess) * totalProcesses);

    if (!procList) {
        perror("Memory allocation failed");
        fclose(processFile);
        exit(EXIT_FAILURE);
    }

    /* Parse file - Phase 2 format: id arrival runtime priority dependencyId base limit */
    int index = 0;
    while (fgets(buffer, sizeof(buffer), processFile)) {
        if (buffer[0] == '#' || buffer[0] == '\n')
            continue;

        /* Parse all 7 fields */
        int fields = sscanf(buffer, "%d %d %d %d %d %d %d",
               &procList[index].ID,
               &procList[index].Time_of_Arrival,
               &procList[index].Time_of_Running,
               &procList[index].Priority,
               &procList[index].dependencyId,
               &procList[index].base_disk,
               &procList[index].limit_pages);
               
        if (fields < 7) {
            printf("Error: Could not parse all 7 fields from line: %s", buffer);
            printf("Expected format: id arrival runtime priority dependencyId base limit\n");
            fclose(processFile);
            free(procList);
            exit(EXIT_FAILURE);
        }
        
        index++;
    }

    fclose(processFile);

    printf("Loaded %d processes from testcase1.txt\n", totalProcesses);

    /* ---------- Select scheduling algorithm ---------- */
    printf("\nSelect scheduling algorithm:\n");
    printf(" %d for HPF\n", HPF);
    printf(" %d for SRTN\n", SRTN);
    printf(" %d for RR\n", RR);
    printf("> ");

    int algorithm;
    scanf("%d", &algorithm);

    int quantum = 1;
    if (algorithm == RR) {
        printf("Enter RR quantum: ");
        scanf("%d", &quantum);
    }

    /* ---------- Create message queue ---------- */
    key_t key = ftok(MSGQUEUENAME, MSGQUEUEKEY);
    SchedulerQueueID = msgget(key, 0666 | IPC_CREAT);
    if (SchedulerQueueID == -1) {
        perror("Message queue error");
        exit(EXIT_FAILURE);
    }

    /* ---------- Start clock ---------- */
    if (fork() == 0) {
        execl("./clk.out", "./clk.out", NULL);
    }

    /* ---------- Start scheduler ---------- */
    if (fork() == 0) {
        char algoStr[8], quantumStr[8], countStr[8];
        snprintf(algoStr, sizeof(algoStr), "%d", algorithm);
        snprintf(quantumStr, sizeof(quantumStr), "%d", quantum);
        snprintf(countStr, sizeof(countStr), "%d", totalProcesses);

        execl("./scheduler.out",
              "./scheduler.out",
              countStr,
              algoStr,
              quantumStr,
              NULL);
    }

    /* ---------- Attach to clock ---------- */
    initClk();

    /* ---------- Send processes at arrival time ---------- */
    for (int i = 0; i < totalProcesses; i++) {

        while (getClk() < procList[i].Time_of_Arrival)
            sleep(1);

        struct ProcessInputMsg msg;
        msg.mtype = MSG_PROC_ARRIVAL;
        msg.data = procList[i];

        printf("Sending process %d: arrival=%d, runtime=%d, base=%d, limit=%d\n",
               procList[i].ID, procList[i].Time_of_Arrival,
               procList[i].Time_of_Running, procList[i].base_disk,
               procList[i].limit_pages);

        if (msgsnd(SchedulerQueueID,
                   &msg,
                   sizeof(struct ProcessInputMsg) - sizeof(long),
                   !IPC_NOWAIT) == -1)
        {
            perror("msgsnd");
            clearResources(0);
        }
    }

    /* ---------- Cleanup ---------- */
    wait(NULL);
    free(procList);
    clearResources(0);
    return 0;
}