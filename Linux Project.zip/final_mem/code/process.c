#include "headers.h"
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>

int remainingtime;
int lastTime;
volatile sig_atomic_t paused = 0;

void handle_pause_signal(int sig) {
    if (sig == SIGUSR1) {
        paused = 1;
        printf("[Process %d] Paused by MMU for page fault\n", getpid());
        
        while (paused) {
            pause();
        }
    }
}

void handle_continue_signal(int sig) {
    if (sig == SIGCONT) {
        paused = 0;
        printf("[Process %d] Resumed after page fault\n", getpid());
    }
}

int main(int argc, char* argv[])
{
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <remaining_time>\n", argv[0]);
        exit(1);
    }
    
    remainingtime = atoi(argv[1]);

    struct sigaction sa_pause, sa_continue;
    
    sa_pause.sa_handler = handle_pause_signal;
    sigemptyset(&sa_pause.sa_mask);
    sa_pause.sa_flags = 0;
    sigaction(SIGUSR1, &sa_pause, NULL);
    
    sa_continue.sa_handler = handle_continue_signal;
    sigemptyset(&sa_continue.sa_mask);
    sa_continue.sa_flags = 0;
    sigaction(SIGCONT, &sa_continue, NULL);

    initClk();

    lastTime = getClk();

    while (remainingtime > 0) {
        if (paused) {
            pause();
            continue;
        }
        
        while (getClk() == lastTime) {
            usleep(1000);
        }
        
        lastTime = getClk();
        remainingtime--;
        
        static int access_counter = 0;
        access_counter++;
        if (access_counter % 3 == 0) {
        }
    }

    key_t key = ftok(MSGQUEUENAME, MSGQUEUEKEY);
    int msqid = msgget(key, 0666);
    ProcessTerminationMsg msg;
    msg.mtype = MSG_PROC_FINISH;
    msg.pid = getpid();

    msgsnd(msqid, &msg, sizeof(msg.pid), 0);

    destroyClk(false);
    return 0;
}