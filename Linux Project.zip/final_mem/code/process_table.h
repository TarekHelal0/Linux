#pragma once
#include "headers.h"
typedef struct PTEntry {
    pcb *proc;         
    struct PTEntry *next;
} PTEntry;

typedef struct {
    PTEntry *head;                 
} ProcessTable;

ProcessTable *ProcessTable_Creation(void);
void Process_table_Elimination(ProcessTable *tbl);
void PCB_Addition(ProcessTable **tbl, pcb *proc);
void PCB_Remove  (ProcessTable **tbl, int procID);
void ProcessTable_Display(ProcessTable *tbl);


