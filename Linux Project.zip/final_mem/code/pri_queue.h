#ifndef PRI_QUEUE_H
#define PRI_QUEUE_H
#include "headers.h" 

typedef struct PriQueue PriQueue;
PriQueue *PriQueueCreation(void);
void   PriQueueInsertion(PriQueue **queue, int key, pcb *process);
pcb      *PriQueue_Dequeue  (PriQueue **queue);
void     PriQueue_Display (PriQueue **queue);
int      PriQueue_IsEmpty(PriQueue **queue);
void     PriQueue_Elimination(PriQueue **queue);

#endif
