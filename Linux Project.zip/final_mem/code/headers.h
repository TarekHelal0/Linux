#pragma once

#include <math.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/file.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define SHKEY         300
#define MSGQUEUEKEY   100
#define MSGQUEUENAME "headers.h"
#define MSG_PROC_ARRIVAL   1
#define MSG_PROC_FINISH    2
#define schedulerLogFile "scheduler.log"
#define schedulerPerfFile "scheduler.perf"
#define memoryLogFile "memory.log"

#define MEMORY_SIZE 512
#define PAGE_SIZE 16
#define TOTAL_PAGES (MEMORY_SIZE / PAGE_SIZE)
#define VIRTUAL_ADDRESS_BITS 10
#define PAGE_OFFSET_BITS 4
#define PAGE_NUMBER_BITS 6
#define DISK_ACCESS_CYCLES 10

#define PTE_VALID   0x01
#define PTE_DIRTY   0x02
#define PTE_REFER   0x04

#define NOT_BLOCKED 0
#define BLOCKED_PAGE_FAULT 1
#define BLOCKED_DISK_ACCESS 2

static int *shmaddr;

static int getClk() { return *shmaddr; }

static void initClk() {
    int shmid = shmget(SHKEY, 4, 0444);
    while (shmid == -1) {                       
        printf("Wait! The clock not initialized yet!\n");
        sleep(1);
        shmid = shmget(SHKEY, 4, 0444);
    }
    shmaddr = (int *)shmat(shmid, (void *)0, 0);
}

static void destroyClk(bool terminateAll) {
    shmdt(shmaddr);
    if (terminateAll) killpg(getpgrp(), SIGINT);
}

enum SchedAlgo     { HPF = 1, SRTN, RR };
enum Processstate  { STARTED, RESUMED, STOPPED, FINISHED, RUNNING };

typedef struct {
    int physical_page;
    int flags;
    int disk_page;
} PageTableEntry;

typedef struct {
    PageTableEntry *entries;
    int size;
    int base_disk;
    int limit_pages;
    int phys_page_table_page;
} ProcessPageTable;

typedef struct {
    int owner_pid;
    int virtual_page;
    int flags;
    int loaded_time;
    int access_time;
} PhysicalPage;

typedef struct {
    PhysicalPage pages[TOTAL_PAGES];
    int clock_hand;
    int free_count;
} MemoryManager;

typedef struct {
    int pid;
    int virtual_page;
    int physical_page;
    int completion_time;
    int is_write;
} DiskOperation;

typedef struct pcb {
    int id;
    int burstTime;
    int arrivalTime;
    int priority;
    int dependencyId;
  
    enum Processstate state;
    int  startTime, stoppedTime, resumedTime, finishTime;
    int  pid;

    int  remainingTimeAfterStop;
    int  waitTime;
    int  remainingTime;
    int  turnaroundTime;
    float weightedTurnaroundTime;

    ProcessPageTable *page_table;
    int memory_allocated;
    int blocked_state;
    int disk_completion_time;
    int next_access_index;
    char access_filename[50];
    
    int base_disk;
    int limit_pages;
} pcb;

typedef struct DataForProcess {
    int ID;
    int Time_of_Arrival;
    int Time_of_Running;
    int Priority;
    int dependencyId;
    int base_disk;
    int limit_pages;
} DataForProcess;

typedef struct ProcessInputMsg {
    long mtype;
    struct DataForProcess data;
} ProcessInputMsg;

typedef struct ProcessTerminationMsg {
    long mtype;
    int pid;
} ProcessTerminationMsg;

typedef struct {
    int access_time;
    int virtual_address;
    char rw;
} MemoryAccess;